from binance.client import Client

client = Client('5yBfTcNLDzwQBCECfhonTS17GolOqrOUD78CwkmuTJZMeXYYO6DccnpNr5WmiKBI', 'ZGURFJV4J5JTWOSU')

# print(client)