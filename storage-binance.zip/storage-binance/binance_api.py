pythonimport json
import requests
import pprint as pp
from candle import Candle
from candleUtil import candleUtil

OPEN = 'open'
HIGH = 'high'
LOW = 'low'
CLOSE = 'close'
INSIDE_BAR = 'insideBar'

class bcolors:
    GREEN = '\033[92m'
    WARNING = '\033[93m'
    RED = '\033[91m'
    ENDC = '\033[0m'

data = []

klines = {}

url = 'https://api.binance.us/api/v3/klines?symbol=BTCUSD&interval=1h&limit=1000'

response = requests.get(f'{url}').json()

# Load response to array
for i in range(len(response)):
    data.append( Candle(response[i]) )
    
for i in range(len(data)):
    if i > 0:
        # if candleUtil.isInsideBar(data[i-1], data[i]):
        #     pp.pprint(data[i].body)
        if candleUtil.hammer(data[i]):
            print(data[i].timestamp)